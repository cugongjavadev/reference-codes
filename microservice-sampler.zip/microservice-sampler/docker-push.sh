#!/bin/bash
docker push benwilcock/config-service:latest
docker push benwilcock/discovery-service:latest
docker push benwilcock/gateway-service:latest
docker push benwilcock/product-query-side:latest
docker push benwilcock/product-command-side:latest

package com.aeoncredit.aeonpay.gateway;

import com.aeoncredit.aeonpay.gateway.prefilters.SimpleLoggingPreFilter;

import javax.sql.DataSource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;
import org.springframework.session.jdbc.config.annotation.web.http.EnableJdbcHttpSession;


/**
 * Created by Chris Adoremos on 08/17/2017.
 */
@SpringBootApplication
@EnableZuulProxy 
@EnableOAuth2Sso
@EnableDiscoveryClient
@EnableJdbcHttpSession
public class GatewayServiceApplication {


    @Bean
    public SimpleLoggingPreFilter simplePreFilter() {
        return new SimpleLoggingPreFilter();
    }

	@Bean
	public DataSource dataSource() {
		return DataSourceBuilder.create().url("jdbc:mariadb://192.168.0.21:3306/aeonpay")
				.username("acss").password("acss").driverClassName("org.mariadb.jdbc.Driver").build();
	}
	
	public static void main(String[] args) {
		SpringApplication.run(GatewayServiceApplication.class, args);
	}
}

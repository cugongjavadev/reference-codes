package com.aeoncredit.aeonpay.registration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Created by Chris Adoremos on 08/17/2017.
 */
@EnableEurekaServer
@SpringBootApplication
public class ServiceRegistrarApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(ServiceRegistrarApplication.class, args);
    }
}
